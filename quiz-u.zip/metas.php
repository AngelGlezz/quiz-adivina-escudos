<?php
	$metas = array(
		"mal" => array(
			"title" => "Adivina Juan",
			"description" => "¿Seguro que te gusta el futbol? Creo que lo tuyo es el rugby o alguno de esos deportes que nadie conoce…",
			"image" => "images/Resultados-1.jpg" 
		),
		"maso" => array(
			"title" => "Adivina Juan",
			"description" => "Podrías mejorar. Te hizo falta echarle Yaytsa",
			"image" => "images/Resultados-2.jpg" 
		),
		"bien" => array(
			"title" => "Adivina Juan",
			"description" => "¡Ni Mister Chip sabe tanto! ¡No sé qué haces contestando este quiz! ¡Tú deberías trabajar en la FIFA!",
			"image" => "images/Resultados-3.jpg" 
		)
	);